/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QuanLyDanhSachSinhVienDatHocBong;

import SinhVien.DanhSachSinhVien;
import SinhVien.SinhVien;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class QuanLySinhVien {
    
    private static final ArrayList<SinhVien> danhSachSinhVien = new ArrayList<>();
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DanhSachSinhVien dssv = new DanhSachSinhVien();
        int choice;
        do{
            System.out.println("\n\n0. Thoat");
            System.out.println("1. Them thong tin sinh vien");
            System.out.println("2. Sua thong tin sinh vien");
            System.out.println("3. Xoa thong tin sinh vien");
            System.out.println("4. Tim kiem thong tin sinh vien");
            System.out.println("5. Xuat thong tin sinh vien");
            System.out.println("6. Xuat danh sach sinh vien nhan hoc bong");
            System.out.println("Moi ban chon: ");
            choice=sc.nextInt();sc.nextLine();
            
            switch (choice) {
                case 0 -> System.out.print("Da thoat chuong trinh.");
                case 1 -> {
                    System.out.print("Nhap so luong sinh vien can them: ");
                    int n = sc.nextInt();
                    sc.nextLine(); // Đọc bỏ dấu enter sau khi nhập số lượng
                    for (int i = 0; i < n; i++) {
                        System.out.println("Sinh vien thu: "+i);
                        System.out.print("Nhap ma so sinh vien: ");
                        String maThem = sc.next();
                        sc.nextLine();
                        System.out.print("Nhap ho ten sinh vien: ");
                        String hotenThem = sc.nextLine();
                        System.out.print("Nhap gioi tinh sinh vien: ");
                        String gioitinhThem = sc.next();
                        System.out.print("Nhap lop sinh vien: ");
                        String lopThem = sc.next();
                        System.out.print("Nhap diem sinh vien: ");
                        float diemThem = sc.nextFloat();
                        SinhVien svThem = new SinhVien(maThem, hotenThem, gioitinhThem, lopThem, diemThem);
                        danhSachSinhVien.add(svThem);
                        dssv.addSinhVien(svThem);
                    }
                }
                case 2 -> {
                    System.out.print("Nhap ma so sinh vien: ");
                    String maSua = sc.next();
                    SinhVien svSua = new SinhVien();
                    dssv.suaSinhVien(maSua, svSua);
                }

                case 3 -> {
                    System.out.print("Nhap ma so sinh vien: ");
                    String maXoa = sc.next();
                    dssv.xoaSinhVien(maXoa);
                }
                case 4 -> {
                    System.out.println("Nhap ma so sinh vien: ");
                    String maSV = sc.next();
                    dssv.timKiemSinhVienTheoMa(maSV);
                }
                case 5 -> dssv.hienThiDanhSachSinhVien();
                case 6 -> dssv.hienThiDanhSachHocBong();
                default -> throw new AssertionError();
            }
        }
        while(choice!=0);
        
       
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SinhVien;

/**
 *
 * @author ASUS
 */
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class DanhSachSinhVien {

    public static Iterable<SinhVien> getDanhSach() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private final ArrayList<SinhVien> danhSachHocSinh;

    public DanhSachSinhVien() {
        this.danhSachHocSinh = new ArrayList<>();
    }

    // Thêm học sinh
    public void addSinhVien(SinhVien sinhvien) {
        danhSachHocSinh.add(sinhvien);
        System.out.println("Them sinh vien thanh cong!");
    }

    // Sửa thông tin học sinh
    public void suaSinhVien(String ma, SinhVien svSua) {
        //sử dụng hàm tìm kiếm sinh viên để kiểm tra sinh viên có tồn tại không
        SinhVien sinhvien = timKiemSinhVienTheoMa(ma);
        if (sinhvien != null) {
            //Tạo chương trình chọn để sửa thông tin cần sửa. Rồi cập nhật lại thông tin.
            System.out.println("Thong tin sinh vien can sua: ");
            System.out.println(sinhvien.toString());
            System.out.println("Ban muon sua thong tin gi?");
            System.out.println("1. Ma sinh vien");
            System.out.println("2. Ho ten sinh vien");
            System.out.println("3. Gioi tinh sinh vien");
            System.out.println("4. Lop sinh vien");
            System.out.println("5. Diem sinh vien");
            System.out.println("6. Tat ca thong tin");
            Scanner scanner = new Scanner(System.in);
            int option = scanner.nextInt();
            scanner.nextLine();
            switch (option) {
                case 1 -> {
                    System.out.print("Nhap ma sinh vien: ");
                    String newMa = scanner.nextLine();
                    sinhvien.setMa(newMa);
                }
                case 2 -> {
                    System.out.print("Nhap ho ten sinh vien: ");
                    String hoten = scanner.nextLine();
                    sinhvien.setHoten(hoten);
                }
                case 3 -> {
                    System.out.print("Nhap gioi tinh sinh vien: ");
                    String gioiTinh = scanner.nextLine();
                    sinhvien.setGioitinh(gioiTinh);
                }
                case 4 -> {
                    System.out.print("Nhap lop sinh vien: ");
                    String lop = scanner.nextLine();
                    sinhvien.setLop(lop);
                }
                case 5 -> {
                    System.out.print("Nhap diem sinh vien: ");
                    float diem = scanner.nextFloat();
                    sinhvien.setDiem(diem);
                }
                case 6 -> {
                    System.out.print("Nhap ma sinh vien: ");
                    String newMa = scanner.nextLine();
                    sinhvien.setMa(newMa);
                    System.out.print("Nhap ho ten sinh vien: ");
                    String hoten = scanner.nextLine();
                    sinhvien.setHoten(hoten);
                    System.out.print("Nhap gioi tinh sinh vien: ");
                    String gioiTinh = scanner.nextLine();
                    sinhvien.setGioitinh(gioiTinh);
                    System.out.print("Nhap lop sinh vien: ");
                    String lop = scanner.nextLine();
                    sinhvien.setLop(lop);
                    System.out.print("Nhap diem sinh vien: ");
                    float diem = scanner.nextFloat();
                    sinhvien.setDiem(diem);
                }
                default -> {
                    System.out.println("Khong co lua chon phu hop");
                    return;
                }
            }
            System.out.println("Sua thong tin sinh vien thanh cong");
        } else {
            System.out.println("Khong tim thay sinh vien can sua");
        }
    }

    
    // Xóa học sinh
    public void xoaSinhVien(String ma) {
        for (SinhVien sv : danhSachHocSinh) {
            if (sv.getMa().equals(ma)) {
                danhSachHocSinh.remove(sv);
                System.out.println("Xoa thong tin sinh vien thanh cong");
                return;
            }
        }
        System.out.println("Khong tim thay sinh vien can xoa");
    }

    // Tìm kiếm học sinh
    public SinhVien timKiemSinhVienTheoMa(String maTim) {
    SinhVien svTimThay = null; // Khởi tạo biến tạm để lưu trữ sinh viên tìm thấy
    for(SinhVien sv : danhSachHocSinh){
        if (sv.getMa().equals(maTim)) {
            System.out.println("Thong tin sinh vien can tim la: ");
            // In thông tin của sinh viên đó
            System.out.println("+--------------+---------+------------------------------+-----------+------+");
            System.out.println("| Ma sinh vien |   Lop   |             Ho ten           | Gioi Tinh | Diem |");
            System.out.println("+--------------+---------+------------------------------+-----------+------+");
            System.out.printf("|%14s|%9s|%30s|%11s|%6.2f|\n", sv.getMa(), sv.getLop(), sv.getHoten(),sv.getGioitinh(),sv.getDiem());
            System.out.println("+--------------+---------+------------------------------+-----------+------+");
            svTimThay = sv; // Lưu trữ sinh viên đầu tiên tìm thấy vào biến tạm
            break; // Kết thúc vòng lặp khi tìm thấy sinh viên
        }
    }
    // Kiểm tra biến tạm để trả về sinh viên tìm thấy hoặc null nếu không tìm thấy
    if (svTimThay == null) {
        System.out.println("Khong co sinh vien trong danh sach");
    }
    return svTimThay;
}

    // Hiển thị danh sách học sinh
    public void hienThiDanhSachSinhVien() {
        //In tiêu đề
        System.out.println("+-----+--------------+---------+------------------------------+-----------+------+");
        System.out.println("| STT | Ma sinh vien |   Lop   |             Ho ten           | Gioi Tinh | Diem |");
        System.out.println("+-----+--------------+---------+------------------------------+-----------+------+");
        int i = 1;//Khai báo biên i để làm stt
        //Tạo vòng lặp để in toàn bộ danh sách sv
        for (SinhVien sv : danhSachHocSinh) {
            System.out.printf("|%5d|%14s|%9s|%30s|%11s|%6.2f|\n", i, sv.getMa(), sv.getLop(), sv.getHoten(),sv.getGioitinh(),sv.getDiem());
            System.out.println("+-----+--------------+---------+------------------------------+-----------+------+");
            i++;
        }
    }
    public void hienThiDanhSachHocBong() {
        // In tiêu đề
        System.out.println("+-----+--------------+---------+------------------------------+-----------+------+----------------------+--------------+");
        System.out.println("| STT | Ma sinh vien |   Lop   |             Ho ten           | Gioi Tinh | Diem |       Hoc bong       | Tien thuong  |");
        System.out.println("+-----+--------------+---------+------------------------------+-----------+------+----------------------+--------------+");
        int i = 1; // Khai báo biến i để làm stt
        // Tạo vòng lặp để in toàn bộ danh sách sinh viên
        for (SinhVien sv : danhSachHocSinh) {
            String hocBong = "";
            double tienThuong = 0;
            double diem = sv.getDiem();
            if (diem >= 6.5 && diem < 8) {
                hocBong = "Hoc Bong Kha";
                tienThuong = 500000;
            } else if (diem >= 8) {
                hocBong = "Hoc Bong Gioi";
                tienThuong = 1500000;
            }else{
                hocBong= "Khong co";
                tienThuong = 0;
            }
            System.out.printf("|%5d|%14s|%9s|%30s|%11s|%6.2f|%22s|%14.0f|\n", i, sv.getMa(), sv.getLop(), sv.getHoten(),sv.getGioitinh(),diem, hocBong, tienThuong);
            System.out.println("+-----+--------------+---------+------------------------------+-----------+------+----------------------+--------------+");
            i++;
        }
    }
}